// /config/khaltiConfig.js
export const khaltiConfig = {
  publicKey: "live_secret_key_68791341fdd94846a146f0457ff7b455", // Replace with your Khalti public key
  paymentVerificationUrl: "https://khalti.com/api/v2/payment/verify/", // Khalti verify URL
};
