// /services/paymentService.js
import axios from "axios";
import { khaltiConfig } from "../config/KhaltiConfig";

export const verifyKhaltiPayment = async (token, amount) => {
  try {
    const response = await axios.post(
      khaltiConfig.paymentVerificationUrl,
      {
        token: token,
        amount: amount,
      },
      {
        headers: {
          Authorization: `Key ${khaltiConfig.secretKey}`,
        },
      }
    );
    return response.data;
  } catch (error) {
    console.error("Payment verification failed:", error);
    throw new Error("Payment verification failed");
  }
};
