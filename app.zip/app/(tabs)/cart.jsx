import React, { useContext, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  StyleSheet,
  Pressable,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import Toast from "react-native-toast-message";
import { useRouter } from "expo-router";
import { CartContext } from "../context/CartProvider";
import { WebView } from "react-native-webview";
import { khaltiConfig } from "../config/KhaltiConfig";

export default function Cart() {
  const { cartItems, addToCart, removeFromCart } = useContext(CartContext);
  const router = useRouter();

  const [paymentURL, setPaymentURL] = useState(null);
  const [loading, setLoading] = useState(false);

  // Calculate the total price in NPR
  const totalPrice = cartItems.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  // Function to handle Khalti checkout
  const handleCheckout = () => {
    if (!cartItems.length) {
      Toast.show({
        type: "error",
        text1: "No items in cart",
        text2: "Please add items to your cart to proceed",
      });
      return;
    }

    setLoading(true);

    // Khalti payment URL with public key and total amount (in paisa, 1 NPR = 100 paisa)
    const paymentLink = `https://www.khalti.com/checkout/#/payment/?public_key=${
      khaltiConfig.publicKey
    }&amount=${totalPrice * 100}`;

    console.log("Payment URL: ", paymentLink); // Debugging the payment URL

    setPaymentURL(paymentLink);
  };

  // Handle the payment status after the WebView redirect
  const onPaymentCompleted = (event) => {
    if (event.nativeEvent.url.includes("payment_success")) {
      setLoading(false);
      Toast.show({
        type: "success",
        text1: "Payment Successful",
        text2: "Your payment has been processed.",
      });
      router.push("/success"); // Redirect to success page after payment
    } else if (event.nativeEvent.url.includes("payment_failure")) {
      setLoading(false);
      Toast.show({
        type: "error",
        text1: "Payment Failed",
        text2: "Something went wrong with your payment.",
      });
    }
  };

  return (
    <SafeAreaView style={styles.wrapper}>
      <Text style={styles.headerText}>Cart</Text>
      <ScrollView style={styles.scrollView}>
        <View style={styles.productContainer}>
          <Text style={styles.headerTextProduct}>Products</Text>
          <View style={styles.productList}>
            {cartItems.length === 0 ? (
              <Text style={styles.noProductText}>No product in cart</Text>
            ) : (
              cartItems.map((item) => (
                <View style={styles.product} key={item.id}>
                  <Image
                    source={{ uri: item.product_img }}
                    style={styles.productImage}
                  />
                  <View style={styles.productInfo}>
                    <Text style={styles.productName}>{item.title}</Text>
                    <Text style={styles.productPrice}>${item.price}</Text>
                    <Text style={styles.productQuantity}>
                      Quantity: {item.quantity}
                    </Text>
                  </View>
                  <View style={styles.productActions}>
                    <Pressable
                      style={styles.actionButton}
                      onPress={() => addToCart(item)}
                    >
                      <Ionicons name="add-circle" size={24} color="green" />
                    </Pressable>
                    <Pressable
                      style={styles.actionButton}
                      onPress={() => removeFromCart(item.id)}
                    >
                      <Ionicons name="remove-circle" size={24} color="red" />
                    </Pressable>
                  </View>
                  <Text style={styles.productTotal}>
                    Total: ${item.price * item.quantity}
                  </Text>
                </View>
              ))
            )}
          </View>
        </View>
      </ScrollView>

      {cartItems.length > 0 && (
        <View style={styles.totalContainer}>
          <Text style={styles.totalText}>Total: ${totalPrice}</Text>
          <Pressable style={styles.button} onPress={handleCheckout}>
            <Text style={styles.buttonText}>Proceed to Checkout</Text>
          </Pressable>
        </View>
      )}

      {paymentURL && !loading ? (
        <WebView
          source={{ uri: paymentURL }}
          style={{ flex: 1 }}
          onNavigationStateChange={onPaymentCompleted}
          startInLoadingState
          onError={(e) => {
            console.error("WebView Error: ", e.nativeEvent);
            setLoading(false);
            Toast.show({
              type: "error",
              text1: "Error occurred while loading Khalti.",
              text2: "Please try again later.",
            });
          }}
          onHttpError={(e) => {
            console.error("WebView HTTP Error: ", e.nativeEvent);
            setLoading(false);
            Toast.show({
              type: "error",
              text1: "Network error.",
              text2: "Unable to load Khalti. Please check your connection.",
            });
          }}
        />
      ) : (
        loading && (
          <Text style={styles.loadingText}>Redirecting to Khalti...</Text>
        )
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    backgroundColor: "#F7F7F7", 
    flex: 1,
  },
  headerText: {
    fontSize: 30,
    fontWeight: "bold",
    color: "#333",
    textAlign: "center",
    marginTop: 20,
    marginBottom: 10,
  },
  scrollView: {
    paddingHorizontal: 20,
  },
  productContainer: {
    marginBottom: 20,
  },
  headerTextProduct: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10,
    textAlign: "center",
  },
  productList: {
    flexDirection: "column",
  },
  product: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  productImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginRight: 15,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  productPrice: {
    fontSize: 16,
    color: "#555",
    marginBottom: 5,
  },
  productQuantity: {
    fontSize: 14,
    color: "#888",
  },
  productActions: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  actionButton: {
    marginHorizontal: 5,
  },
  productTotal: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
    marginTop: 10,
  },
  noProductText: {
    fontSize: 18,
    color: "#888",
    textAlign: "center",
    marginTop: 20,
  },
  totalContainer: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 12,
    marginHorizontal: 20,
    marginBottom: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  totalText: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 15,
  },
  button: {
    backgroundColor: "#F44336", // Red button
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 20,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  loadingText: {
    textAlign: "center",
    fontSize: 18,
    color: "#F44336",
    marginTop: 20,
  },
});
